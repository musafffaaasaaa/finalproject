# finalproject
Serikov Samat, Mazhikenova Aigerim, Abilkhan Mustafa
