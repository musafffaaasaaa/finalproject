package data

type Order struct {
}